using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DigitalLockerSystem.Views.Admin;

public class BlockUser : PageModel
{
    public void OnGet()
    {
        
    }
}