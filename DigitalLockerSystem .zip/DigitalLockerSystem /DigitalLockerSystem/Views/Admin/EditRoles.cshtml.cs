using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DigitalLockerSystem.Views.Admin;

public class EditRoles : PageModel
{
    public void OnGet()
    {
        
    }
}