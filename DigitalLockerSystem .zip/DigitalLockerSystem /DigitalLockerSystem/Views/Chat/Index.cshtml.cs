using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DigitalLockerSystem.Views.Chat;

public class Index : PageModel
{
    public void OnGet()
    {
        
    }
}