using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DigitalLockerSystem.Views.Files;

public class MyFiles : PageModel
{
    public void OnGet()
    {
        
    }
}