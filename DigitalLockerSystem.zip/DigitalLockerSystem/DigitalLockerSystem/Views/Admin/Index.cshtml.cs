using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DigitalLockerSystem.Views.Admin;

public class Index : PageModel
{
    public void OnGet()
    {
        
    }
}