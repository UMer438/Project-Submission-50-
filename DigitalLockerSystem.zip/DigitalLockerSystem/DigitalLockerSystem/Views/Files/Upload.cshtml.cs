using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DigitalLockerSystem.Views.Files;

public class Upload : PageModel
{
    public void OnGet()
    {
        
    }
}